To run the application, please run from the project's root dir like:

    `python3 ./src/goodchain.py`

Otherwise there might be issues finding the various data files.